package com.example.autofishing;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.view.ViewGroup;
import android.graphics.Color;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(32,48,32,32);
        root.setBackgroundColor(Color.WHITE);
        TextView title = new TextView(this);
        title.setText("Auto Fishing\n\n1. 접근성 권한을 켜세요.\n2. 게임 화면에서 시작을 누르세요.\n\n인식 문구:\n• 길게 눌러 캐스팅하기\n• 빠르게 클릭하세요\n\n화면 문구가 인식되면 해당 문구 주변을 터치합니다.");
        title.setTextSize(18);
        root.addView(title, new LinearLayout.LayoutParams(-1,0,1));
        Button access = new Button(this);
        access.setText("접근성 설정 열기");
        access.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        root.addView(access);
        Button start = new Button(this);
        start.setText("자동 낚시 시작");
        start.setOnClickListener(v -> getSharedPreferences("auto",0).edit().putBoolean("running",true).apply());
        root.addView(start);
        Button stop = new Button(this);
        stop.setText("정지");
        stop.setOnClickListener(v -> getSharedPreferences("auto",0).edit().putBoolean("running",false).apply());
        root.addView(stop);
        setContentView(root);
    }
}
