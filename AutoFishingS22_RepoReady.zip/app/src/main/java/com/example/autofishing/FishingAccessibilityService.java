package com.example.autofishing;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.AccessibilityService.ScreenshotResult;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.Rect;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.accessibility.AccessibilityEvent;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions;

public class FishingAccessibilityService extends AccessibilityService {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final TextRecognizer recognizer = TextRecognition.getClient(new KoreanTextRecognizerOptions.Builder().build());
    private boolean busy = false;
    private long lastAction = 0;

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { busy = false; }

    @Override protected void onServiceConnected() {
        super.onServiceConnected();
        handler.post(loop);
    }

    private final Runnable loop = new Runnable() {
        @Override public void run() {
            if (getSharedPreferences("auto", MODE_PRIVATE).getBoolean("running", false) && !busy) {
                if (android.os.Build.VERSION.SDK_INT >= 30) {
                    busy = true;
                    takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
                        @Override public void onSuccess(ScreenshotResult result) {
                            Bitmap bitmap = Bitmap.wrapHardwareBuffer(result.getHardwareBuffer(), result.getColorSpace());
                            if (bitmap != null) {
                                Bitmap copy = bitmap.copy(Bitmap.Config.ARGB_8888, false);
                                result.getHardwareBuffer().close();
                                if (copy != null) recognize(copy);
                            } else {
                                result.getHardwareBuffer().close();
                                busy = false;
                            }
                        }
                        @Override public void onFailure(int errorCode) { busy = false; }
                    });
                }
            }
            handler.postDelayed(this, 1200);
        }
    };

    private void recognize(Bitmap bitmap) {
        recognizer.process(InputImage.fromBitmap(bitmap,0))
            .addOnSuccessListener(text -> {
                if (!getSharedPreferences("auto", MODE_PRIVATE).getBoolean("running",false)) { busy=false; bitmap.recycle(); return; }
                long now = System.currentTimeMillis();
                if (now-lastAction < 2500) { busy=false; bitmap.recycle(); return; }
                for (Text.TextBlock block : text.getTextBlocks()) {
                    String s = block.getText();
                    Rect r = block.getBoundingBox();
                    if (r == null) continue;
                    float x = r.exactCenterX(), y = r.exactCenterY();
                    if (s.contains("길게 눌러") && s.contains("캐스팅")) {
                        lastAction=now; longPress(x,y,2000); break;
                    } else if (s.contains("빠르게") && s.contains("클릭")) {
                        lastAction=now; rapidTap(x,y,10); break;
                    }
                }
                busy=false; bitmap.recycle();
            })
            .addOnFailureListener(e -> { busy=false; bitmap.recycle(); });
    }

    private void longPress(float x, float y, long duration) {
        Path p = new Path(); p.moveTo(x,y);
        GestureDescription.StrokeDescription stroke = new GestureDescription.StrokeDescription(p,0,duration);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(), null, null);
    }

    private void rapidTap(float x, float y, int count) {
        Path p = new Path(); p.moveTo(x,y);
        GestureDescription.Builder b = new GestureDescription.Builder();
        long t=0;
        for (int i=0;i<count;i++) {
            Path tap = new Path(); tap.moveTo(x,y);
            b.addStroke(new GestureDescription.StrokeDescription(tap,t,45));
            t += 85;
        }
        dispatchGesture(b.build(), null, null);
    }
    @Override public void onDestroy() {
        handler.removeCallbacks(loop);
        recognizer.close();
        super.onDestroy();
    }
}
